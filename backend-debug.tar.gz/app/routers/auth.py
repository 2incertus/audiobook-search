from datetime import timedelta

from fastapi import APIRouter, HTTPException, status

from app.auth import verify_password, create_access_token
from app.config import settings
from app.schemas import LoginRequest, TokenResponse

router = APIRouter()


@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest):
    # Debug logging
    import logging
    logger = logging.getLogger(__name__)
    logger.info(f"Login attempt - password length: {len(request.password)}, first 2 chars: {request.password[:2] if request.password else 'empty'}")

    if not verify_password(request.password):
        logger.warning(f"Password verification failed")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect password",
        )
    access_token = create_access_token(
        expires_delta=timedelta(minutes=settings.access_token_expire_minutes)
    )
    return TokenResponse(access_token=access_token)
