from dataclasses import dataclass
from typing import Callable, Dict, List, Optional
from urllib.parse import quote_plus, urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from scrapers.tokybook import TokybookScraper
from scrapers.zaudiobooks import ZaudiobooksScraper
from scrapers.goldenaudiobook import GoldenAudiobookScraper
from scrapers.fulllengthaudiobooks import FulllengthAudiobooksScraper
from scrapers.hdaudiobooks import HDAudiobooksScraper
from scrapers.bigaudiobooks import BigAudiobooksScraper


USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)


@dataclass
class SearchResult:
    title: str
    url: str
    site: str
    author: Optional[str] = None
    cover_url: Optional[str] = None
    match: Optional[str] = None
    score: float = 0.0


def get_scraper(url: str):
    """Factory function to select the correct scraper based on the URL."""
    if "tokybook.com" in url:
        return TokybookScraper()
    if "goldenaudiobook.net" in url or "goldenaudiobook.com" in url:
        return GoldenAudiobookScraper()
    if "zaudiobooks.com" in url:
        return ZaudiobooksScraper()
    if "fulllengthaudiobooks.net" in url:
        return FulllengthAudiobooksScraper()
    if "hdaudiobooks.net" in url:
        return HDAudiobooksScraper()
    if "bigaudiobooks.net" in url:
        return BigAudiobooksScraper()
    return None


def search_tokybook(query: str, limit: int = 5) -> List[SearchResult]:
    """Hit the Tokybook public search API."""
    api_url = "https://tokybook.com/api/v1/search?searchTerm=" + quote_plus(query.strip())
    headers = {"User-Agent": USER_AGENT}
    results: List[SearchResult] = []

    try:
        resp = requests.get(api_url, headers=headers, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        items = data.get("items") or data.get("data") or []
        for item in items:
            slug = (
                item.get("dynamicSlugId")
                or item.get("slugId")
                or item.get("slug")
                or item.get("postId")
            )
            if not slug:
                continue
            url = f"https://tokybook.com/post/{slug}"
            title = item.get("title") or "Unknown Title"
            author = None
            if item.get("authors"):
                author = item["authors"][0].get("name")
            results.append(
                SearchResult(
                    title=title.strip(),
                    url=url,
                    site="tokybook.com",
                    author=author,
                    cover_url=item.get("coverImage"),
                )
            )
            if len(results) >= limit:
                break
    except Exception:
        return []

    return results


def _search_wordpress_site(base_url: str, query: str, limit: int = 5) -> List[SearchResult]:
    """Generic WordPress search helper for audiobook sites."""
    search_url = f"{base_url}/?s={quote_plus(query.strip())}"
    headers = {"User-Agent": USER_AGENT, "Referer": base_url}
    results: List[SearchResult] = []

    try:
        resp = requests.get(search_url, headers=headers, timeout=10)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")

        link_nodes = soup.select(
            "h2.entry-title a, h2.post-title a, h1.title-page a, h3.post-title a"
        )
        for node in link_nodes:
            href = node.get("href")
            if not href:
                continue
            full_url = href if href.startswith("http") else urljoin(base_url, href)
            title_text = node.get_text(strip=True) or "Unknown Title"
            results.append(
                SearchResult(
                    title=title_text,
                    url=full_url,
                    site=urlparse(base_url).netloc,
                )
            )
            if len(results) >= limit:
                break
    except Exception:
        return []

    return results


def search_zaudiobooks(query: str, limit: int = 5) -> List[SearchResult]:
    return _search_wordpress_site("https://zaudiobooks.com", query, limit)


def search_fulllengthaudiobooks(query: str, limit: int = 5) -> List[SearchResult]:
    return _search_wordpress_site("https://fulllengthaudiobooks.net", query, limit)


def search_hdaudiobooks(query: str, limit: int = 5) -> List[SearchResult]:
    return _search_wordpress_site("https://hdaudiobooks.net", query, limit)


def search_bigaudiobooks(query: str, limit: int = 5) -> List[SearchResult]:
    return _search_wordpress_site("https://bigaudiobooks.net", query, limit)


def search_goldenaudiobook(query: str, limit: int = 5) -> List[SearchResult]:
    results = _search_wordpress_site("https://goldenaudiobook.net", query, limit)
    if len(results) < limit:
        results += _search_wordpress_site("https://goldenaudiobook.com", query, limit - len(results))
    return results


SEARCHERS: Dict[str, Callable[[str, int], List[SearchResult]]] = {
    "tokybook.com": search_tokybook,
    "zaudiobooks.com": search_zaudiobooks,
    "fulllengthaudiobooks.net": search_fulllengthaudiobooks,
    "hdaudiobooks.net": search_hdaudiobooks,
    "bigaudiobooks.net": search_bigaudiobooks,
    "goldenaudiobook.net": search_goldenaudiobook,
    "goldenaudiobook.com": search_goldenaudiobook,
}

SUPPORTED_SITES = list(SEARCHERS.keys())


def search_all(
    query: str,
    sites: Optional[List[str]] = None,
    per_site_limit: int = 5,
    max_pages: int = 3,
) -> List[SearchResult]:
    """Run the query across the requested sites and return a combined list."""
    if not query.strip():
        return []

    target_sites = sites or list(SEARCHERS.keys())
    aggregated: List[SearchResult] = []
    for site in target_sites:
        searcher = SEARCHERS.get(site)
        if not searcher:
            continue
        aggregated.extend(searcher(query, per_site_limit))

    return aggregated
