from typing import Annotated

from fastapi import APIRouter, Depends

from app.auth import get_current_user
from app.schemas import SearchRequest, SearchResponse, SearchResult
from scrapers import search_all, SUPPORTED_SITES

router = APIRouter()


@router.post("", response_model=SearchResponse)
async def search_audiobooks(
    request: SearchRequest,
    _user: Annotated[str, Depends(get_current_user)],
):
    sites = request.sites or SUPPORTED_SITES
    results = search_all(
        query=request.query,
        sites=sites,
        per_site_limit=request.limit,
        max_pages=request.max_pages,
    )

    return SearchResponse(
        results=[
            SearchResult(
                title=r.title,
                author=r.author,
                site=r.site,
                url=r.url,
                cover_url=getattr(r, "cover_url", None),
                match=getattr(r, "match", None),
                score=getattr(r, "score", 0.0),
            )
            for r in results
        ]
    )


@router.get("/sites")
async def get_supported_sites(
    _user: Annotated[str, Depends(get_current_user)],
):
    return {"sites": SUPPORTED_SITES}
